#pragma once

#include "Tavle.h"

class MainWindow : public BaseWindow<MainWindow>
{
public:
	CLASS_NAME_OVERRIDE(MainWindow);
	std::shared_ptr<GraphicsModule<MainWindow>> graphicsModule;
public:
	MainWindow();

};



